$(document).ready(function () {
    // prepare the data
    var polarData = [//{Angle: 10, Pressure : 40},
			//{Angle: 50, Pressure : 80},
			//{Angle: 90, Pressure : 70},
			//{Angle: 130, Pressure : 80},
			{Angle: 170, Pressure : 30},
			{Angle: 210, Pressure : 40},
			{Angle: 250, Pressure : 70},
			{Angle: 290, Pressure : 20},
			{Angle: 330, Pressure : 40},
			{Angle: 360, Pressure : 60}];
            var source =
            {
				localdata: polarData,
                datatype: "array"
            };
            var dataAdapter = new $.jqx.dataAdapter(source, { async: false, autoBind: true });
           var settings = {
    title: "Pressure Far Field Plot",
    description: "",
    enableAnimations: true,
    showLegend: true,
    padding: { left: 5, top: 5, right: 5, bottom: 5 },
    titlePadding: { left: 0, top: 0, right: 0, bottom: 5 },
    source: dataAdapter,
    xAxis:
    {
        dataField: 'Angle',
        unitInterval: 30,
        minValue: 0,
        maxValue: 360,
        valuesOnTicks: true,
        flip: true,
        labels: { autoRotate: true },
        type: 'linear',
        formatFunction(value) {
            if (value === 360) {
                return ' '; // 360 is not shown over 0
            }
            return value;
        }
    },
    colorScheme: 'scheme01',
    seriesGroups:
        [
            {
                polar: true,
                radius: 120,
                startAngle: 90,
                endAngle: 90 + 359.99,
                type: 'line',
                valueAxis:
                {
                    labels: {
                        formatSettings: { decimalPlaces: 0 },
                        autoRotate: true
                    }
                },
                series: [
                        { dataField: 'Pressure', displayText: 'Pressure', opacity: 0.7, lineWidth: 1, radius: 2, lineWidth: 2 }
                ]
            }
        ]
};
    // create the chart
    $('#chartContainer').jqxChart(settings);
    // get the chart's instance
    var chart = $('#chartContainer').jqxChart('getInstance');
    // start angle slider
    $('#sliderStartAngle').jqxSlider({ width: 240, min: 0, max: 360, step: 1, ticksFrequency: 20, mode: 'fixed' });
    $('#sliderStartAngle').on('change', function (event) {
        var value = event.args.value;
        chart.seriesGroups[0].startAngle = value;
        chart.seriesGroups[0].endAngle = value + 360;
        chart.update();
    });
    // radius slider
    $('#sliderRadius').jqxSlider({ width: 240, min: 80, max: 140, value: 120, step: 1, ticksFrequency: 20, mode: 'fixed' });
    $('#sliderRadius').on('change', function (event) {
        var value = event.args.value;
        chart.seriesGroups[0].radius = value;
        chart.update();
    });
    // color scheme drop down
    var colorsSchemesList = ["scheme01", "scheme02", "scheme03", "scheme04", "scheme05", "scheme06", "scheme07", "scheme08"];
    $("#dropDownColors").jqxDropDownList({ source: colorsSchemesList, selectedIndex: 2, width: '200', height: '25', dropDownHeight: 100 });
    $('#dropDownColors').on('change', function (event) {
        var value = event.args.item.value;
        chart.colorScheme = value;
        chart.update();
    });
    // series type drop down
    var seriesList = ["splinearea", "spline", "column", "scatter", "stackedcolumn", "stackedsplinearea", "stackedspline"];
    $("#dropDownSeries").jqxDropDownList({ source: seriesList, selectedIndex: 0, width: '200', height: '25', dropDownHeight: 100 });
    $('#dropDownSeries').on('select', function (event) {
        var args = event.args;
        if (args) {
            var value = args.item.value;
            chart.seriesGroups[0].type = value;
            chart.update();
        }
    });
    // series type drop down
    var plotStyleList = ["polar", "line"];
    $("#dropDownPlotStyle").jqxDropDownList({ source: plotStyleList, selectedIndex: 0, width: '200', height: '25', dropDownHeight: 60 });
    $('#dropDownPlotStyle').on('select', function (event) {
        var args = event.args;
        if (args) {
            var value = args.item.value;
            if (value == "polar") {
                chart.seriesGroups[0].polar = true;
                // refresh the chart element
                $('#chartContainer').jqxChart('refresh');
            }
            else {
                chart.seriesGroups[0].polar = false;
                chart.xAxis.flip = false;
            }
            chart.update();
        }
    });
});
